if (
    sessionStorage.getItem("uid") != "" &&
    sessionStorage.getItem("uid") != null
  ) {
    // window.location.href = "admin.html";
  }
